<?php
/**
 * Plugin Name: LTA Recruitment Sync
 * Description: Đồng bộ thông tin tuyển dụng từ hệ thống LTA với WordPress
 * Version: 1.0.0
 * Author: LTA Team
 */

if (!defined('ABSPATH')) {
    exit;
}

class LTA_Recruitment_Sync {
    
    public function __construct() {
        add_action('init', array($this, 'init'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('wp_ajax_lta_sync_recruitment', array($this, 'ajax_sync_recruitment'));
        add_action('wp_ajax_nopriv_lta_sync_recruitment', array($this, 'ajax_sync_recruitment'));
        
        register_activation_hook(__FILE__, array($this, 'activate'));
    }
    
    public function init() {
        $this->create_table();
    }
    
    public function activate() {
        $this->create_table();
        add_option('lta_recruitment_sync_api_key', '');
    }
    
    private function create_table() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'lta_recruitment';
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id varchar(50) NOT NULL,
            title text NOT NULL,
            position varchar(255) NOT NULL,
            location varchar(255) NOT NULL,
            salary varchar(255) NOT NULL,
            type varchar(50) NOT NULL,
            status varchar(50) NOT NULL DEFAULT 'active',
            description longtext NOT NULL,
            requirements longtext NOT NULL,
            benefits longtext NOT NULL,
            experience varchar(255) NOT NULL,
            education varchar(255) NOT NULL,
            deadline datetime NOT NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY (id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    public function add_admin_menu() {
        add_menu_page(
            'LTA Recruitment',
            'LTA Recruitment',
            'manage_options',
            'lta-recruitment',
            array($this, 'admin_page'),
            'dashicons-businessman',
            81
        );
    }
    
    public function admin_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        $message = '';
        if (isset($_POST['lta_save_settings'])) {
            check_admin_referer('lta_recruitment_save');
            $api_key = sanitize_text_field($_POST['api_key']);
            update_option('lta_recruitment_sync_api_key', $api_key);
            $message = 'Cập nhật thành công!';
        }
        
        $api_key = get_option('lta_recruitment_sync_api_key', '');
        ?>
        <div class="wrap">
            <h1>LTA Recruitment Sync</h1>
            
            <?php if (!empty($message)): ?>
                <div class="notice notice-success">
                    <p><?php echo esc_html($message); ?></p>
                </div>
            <?php endif; ?>
            
            <div class="card">
                <h2>Cấu hình</h2>
                <form method="post">
                    <?php wp_nonce_field('lta_recruitment_save'); ?>
                    <table class="form-table">
                        <tr>
                            <th>API Key:</th>
                            <td>
                                <input type="text" name="api_key" value="<?php echo esc_attr($api_key); ?>" class="regular-text" />
                            </td>
                        </tr>
                    </table>
                    <p><input type="submit" name="lta_save_settings" class="button-primary" value="Lưu" /></p>
                </form>
            </div>
            
            <div class="card">
                <h2>API Endpoints</h2>
                <p><strong>URL:</strong> <?php echo admin_url('admin-ajax.php'); ?></p>
                <p><strong>Action:</strong> lta_sync_recruitment</p>
                <p><strong>Method:</strong> POST</p>
                <p><strong>Parameters:</strong> action, api_key, recruitment</p>
            </div>
        </div>
        <?php
    }
    
    public function ajax_sync_recruitment() {
        $api_key = sanitize_text_field($_POST['api_key'] ?? '');
        $stored_key = get_option('lta_recruitment_sync_api_key', '');
        
        if (empty($stored_key) || $api_key !== $stored_key) {
            wp_die(json_encode(['success' => false, 'message' => 'API key không hợp lệ']));
        }
        
        $recruitment_data = $_POST['recruitment'] ?? null;
        if (!$recruitment_data) {
            wp_die(json_encode(['success' => false, 'message' => 'Dữ liệu không hợp lệ']));
        }
        
        $result = $this->sync_recruitment($recruitment_data);
        wp_die(json_encode($result));
    }
    
    private function sync_recruitment($data) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'lta_recruitment';
        
        $recruitment = array(
            'id' => sanitize_text_field($data['id']),
            'title' => sanitize_text_field($data['title']),
            'position' => sanitize_text_field($data['position']),
            'location' => sanitize_text_field($data['location']),
            'salary' => sanitize_text_field($data['salary']),
            'type' => sanitize_text_field($data['type']),
            'status' => sanitize_text_field($data['status']),
            'description' => wp_kses_post($data['description']),
            'requirements' => maybe_serialize($data['requirements']),
            'benefits' => maybe_serialize($data['benefits']),
            'experience' => sanitize_text_field($data['experience']),
            'education' => sanitize_text_field($data['education']),
            'deadline' => sanitize_text_field($data['deadline']),
            'created_at' => sanitize_text_field($data['createdAt']),
            'updated_at' => sanitize_text_field($data['updatedAt'])
        );
        
        $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %s", $recruitment['id']));
        
        if ($existing) {
            $result = $wpdb->update($table_name, $recruitment, array('id' => $recruitment['id']));
        } else {
            $result = $wpdb->insert($table_name, $recruitment);
        }
        
        if ($result === false) {
            return array('success' => false, 'message' => 'Lỗi: ' . $wpdb->last_error);
        }
        
        return array('success' => true, 'message' => 'Đồng bộ thành công');
    }
}

new LTA_Recruitment_Sync();
