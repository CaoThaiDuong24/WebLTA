<?php
/**
 * Plugin Name: LTA Recruitment Sync
 * Description: Đồng bộ thông tin tuyển dụng từ hệ thống LTA với WordPress
 * Version: 1.0.1
 * Author: LTA Team
 */

if (!defined('ABSPATH')) {
    exit;
}

class LTA_Recruitment_Sync {
    
    public function __construct() {
        add_action('init', array($this, 'init'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('wp_ajax_lta_sync_recruitment', array($this, 'ajax_sync_recruitment'));
        add_action('wp_ajax_nopriv_lta_sync_recruitment', array($this, 'ajax_sync_recruitment'));
        add_action('wp_ajax_lta_get_recruitment', array($this, 'ajax_get_recruitment'));
        add_action('wp_ajax_nopriv_lta_get_recruitment', array($this, 'ajax_get_recruitment'));
        add_action('wp_ajax_lta_delete_recruitment', array($this, 'ajax_delete_recruitment'));
        add_action('wp_ajax_nopriv_lta_delete_recruitment', array($this, 'ajax_delete_recruitment'));
        
        // Shortcode
        add_shortcode('lta_recruitment', array($this, 'shortcode_display'));
        
        register_activation_hook(__FILE__, array($this, 'activate'));
    }
    
    public function init() {
        $this->create_table();
    }
    
    public function activate() {
        $this->create_table();
        // Set default API key if not exists
        if (!get_option('lta_recruitment_sync_api_key')) {
            add_option('lta_recruitment_sync_api_key', 'lta_recruitment_2024');
        }
    }
    
    private function create_table() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'lta_recruitment';
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id varchar(50) NOT NULL,
            title text NOT NULL,
            position varchar(255) NOT NULL,
            location varchar(255) NOT NULL,
            salary varchar(255) NOT NULL,
            type varchar(50) NOT NULL,
            status varchar(50) NOT NULL DEFAULT 'active',
            description longtext NOT NULL,
            requirements longtext NOT NULL,
            benefits longtext NOT NULL,
            experience varchar(255) NOT NULL,
            education varchar(255) NOT NULL,
            deadline datetime NOT NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY (id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    public function add_admin_menu() {
        add_menu_page(
            'LTA Recruitment',
            'LTA Recruitment',
            'manage_options',
            'lta-recruitment',
            array($this, 'admin_page'),
            'dashicons-businessman',
            81
        );
        
        add_submenu_page(
            'lta-recruitment',
            'Quản lý dữ liệu',
            'Quản lý dữ liệu',
            'manage_options',
            'lta-recruitment-data',
            array($this, 'data_management_page')
        );
    }
    
    public function admin_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        $message = '';
        if (isset($_POST['lta_save_settings'])) {
            check_admin_referer('lta_recruitment_save');
            $api_key = sanitize_text_field($_POST['api_key']);
            update_option('lta_recruitment_sync_api_key', $api_key);
            $message = 'Cập nhật thành công!';
        }
        
        $api_key = get_option('lta_recruitment_sync_api_key', 'lta_recruitment_2024');
        ?>
        <div class="wrap">
            <h1>LTA Recruitment Sync</h1>
            
            <?php if (!empty($message)): ?>
                <div class="notice notice-success">
                    <p><?php echo esc_html($message); ?></p>
                </div>
            <?php endif; ?>
            
            <div class="card">
                <h2>Cấu hình</h2>
                <form method="post">
                    <?php wp_nonce_field('lta_recruitment_save'); ?>
                    <table class="form-table">
                        <tr>
                            <th>API Key:</th>
                            <td>
                                <input type="text" name="api_key" value="<?php echo esc_attr($api_key); ?>" class="regular-text" />
                                <p class="description">API key mặc định: lta_recruitment_2024</p>
                            </td>
                        </tr>
                    </table>
                    <p><input type="submit" name="lta_save_settings" class="button-primary" value="Lưu" /></p>
                </form>
            </div>
            
            <div class="card">
                <h2>API Endpoints</h2>
                <p><strong>URL:</strong> <?php echo admin_url('admin-ajax.php'); ?></p>
                <p><strong>Action:</strong> lta_sync_recruitment</p>
                <p><strong>Method:</strong> POST</p>
                <p><strong>Parameters:</strong> action, api_key, recruitment</p>
                
                <h3>Thêm Endpoints:</h3>
                <p><strong>Lấy dữ liệu:</strong> action=lta_get_recruitment</p>
                <p><strong>Xóa dữ liệu:</strong> action=lta_delete_recruitment</p>
            </div>
            
            <div class="card">
                <h2>Shortcode</h2>
                <p>Sử dụng shortcode để hiển thị danh sách tuyển dụng:</p>
                <code>[lta_recruitment limit="5" status="active"]</code>
                <p><strong>Parameters:</strong></p>
                <ul>
                    <li><strong>limit:</strong> Số lượng hiển thị (mặc định: 10)</li>
                    <li><strong>status:</strong> Trạng thái (active/inactive, mặc định: all)</li>
                </ul>
            </div>
        </div>
        <?php
    }
    
    public function data_management_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'lta_recruitment';
        
        // Handle delete action
        if (isset($_GET['delete']) && wp_verify_nonce($_GET['_wpnonce'], 'delete_recruitment')) {
            $id = sanitize_text_field($_GET['delete']);
            $wpdb->delete($table_name, array('id' => $id));
            echo '<div class="notice notice-success"><p>Đã xóa thành công!</p></div>';
        }
        
        $recruitments = $wpdb->get_results("SELECT * FROM $table_name ORDER BY created_at DESC");
        ?>
        <div class="wrap">
            <h1>Quản lý dữ liệu tuyển dụng</h1>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Vị trí</th>
                        <th>Địa điểm</th>
                        <th>Lương</th>
                        <th>Trạng thái</th>
                        <th>Hạn nộp</th>
                        <th>Thao tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($recruitments): ?>
                        <?php foreach ($recruitments as $rec): ?>
                            <tr>
                                <td><?php echo esc_html($rec->id); ?></td>
                                <td><?php echo esc_html($rec->position); ?></td>
                                <td><?php echo esc_html($rec->location); ?></td>
                                <td><?php echo esc_html($rec->salary); ?></td>
                                <td><?php echo esc_html($rec->status); ?></td>
                                <td><?php echo esc_html($rec->deadline); ?></td>
                                <td>
                                    <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=lta-recruitment-data&delete=' . $rec->id), 'delete_recruitment'); ?>" 
                                       onclick="return confirm('Bạn có chắc muốn xóa?')" 
                                       class="button button-small button-link-delete">Xóa</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7">Chưa có dữ liệu tuyển dụng</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
    
    public function ajax_sync_recruitment() {
        $api_key = sanitize_text_field($_POST['api_key'] ?? '');
        $stored_key = get_option('lta_recruitment_sync_api_key', 'lta_recruitment_2024');
        
        if (empty($stored_key) || $api_key !== $stored_key) {
            wp_die(json_encode(['success' => false, 'message' => 'API key không hợp lệ']));
        }
        
        $recruitment_data = $_POST['recruitment'] ?? null;
        if (!$recruitment_data) {
            wp_die(json_encode(['success' => false, 'message' => 'Dữ liệu không hợp lệ']));
        }
        
        $result = $this->sync_recruitment($recruitment_data);
        wp_die(json_encode($result));
    }
    
    public function ajax_get_recruitment() {
        $api_key = sanitize_text_field($_POST['api_key'] ?? '');
        $stored_key = get_option('lta_recruitment_sync_api_key', 'lta_recruitment_2024');
        
        if (empty($stored_key) || $api_key !== $stored_key) {
            wp_die(json_encode(['success' => false, 'message' => 'API key không hợp lệ']));
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'lta_recruitment';
        $recruitments = $wpdb->get_results("SELECT * FROM $table_name ORDER BY created_at DESC");
        
        wp_die(json_encode(['success' => true, 'data' => $recruitments]));
    }
    
    public function ajax_delete_recruitment() {
        $api_key = sanitize_text_field($_POST['api_key'] ?? '');
        $stored_key = get_option('lta_recruitment_sync_api_key', 'lta_recruitment_2024');
        
        if (empty($stored_key) || $api_key !== $stored_key) {
            wp_die(json_encode(['success' => false, 'message' => 'API key không hợp lệ']));
        }
        
        $id = sanitize_text_field($_POST['id'] ?? '');
        if (empty($id)) {
            wp_die(json_encode(['success' => false, 'message' => 'ID không hợp lệ']));
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'lta_recruitment';
        $result = $wpdb->delete($table_name, array('id' => $id));
        
        if ($result === false) {
            wp_die(json_encode(['success' => false, 'message' => 'Lỗi xóa dữ liệu']));
        }
        
        wp_die(json_encode(['success' => true, 'message' => 'Xóa thành công']));
    }
    
    public function shortcode_display($atts) {
        $atts = shortcode_atts(array(
            'limit' => 10,
            'status' => 'all'
        ), $atts);
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'lta_recruitment';
        
        $where_clause = '';
        if ($atts['status'] !== 'all') {
            $where_clause = $wpdb->prepare(" WHERE status = %s", $atts['status']);
        }
        
        $recruitments = $wpdb->get_results(
            "SELECT * FROM $table_name" . $where_clause . " ORDER BY created_at DESC LIMIT " . intval($atts['limit'])
        );
        
        if (empty($recruitments)) {
            return '<p>Không có tin tuyển dụng nào.</p>';
        }
        
        $output = '<div class="lta-recruitment-list">';
        foreach ($recruitments as $rec) {
            $output .= '<div class="lta-recruitment-item" style="border: 1px solid #ddd; padding: 15px; margin: 10px 0; border-radius: 5px;">';
            $output .= '<h3>' . esc_html($rec->position) . '</h3>';
            $output .= '<p><strong>Địa điểm:</strong> ' . esc_html($rec->location) . '</p>';
            $output .= '<p><strong>Lương:</strong> ' . esc_html($rec->salary) . '</p>';
            $output .= '<p><strong>Kinh nghiệm:</strong> ' . esc_html($rec->experience) . '</p>';
            $output .= '<p><strong>Hạn nộp:</strong> ' . esc_html($rec->deadline) . '</p>';
            $output .= '<p>' . wp_kses_post($rec->description) . '</p>';
            $output .= '</div>';
        }
        $output .= '</div>';
        
        return $output;
    }
    
    private function sync_recruitment($data) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'lta_recruitment';
        
        $recruitment = array(
            'id' => sanitize_text_field($data['id']),
            'title' => sanitize_text_field($data['title']),
            'position' => sanitize_text_field($data['position']),
            'location' => sanitize_text_field($data['location']),
            'salary' => sanitize_text_field($data['salary']),
            'type' => sanitize_text_field($data['type']),
            'status' => sanitize_text_field($data['status']),
            'description' => wp_kses_post($data['description']),
            'requirements' => maybe_serialize($data['requirements']),
            'benefits' => maybe_serialize($data['benefits']),
            'experience' => sanitize_text_field($data['experience']),
            'education' => sanitize_text_field($data['education']),
            'deadline' => sanitize_text_field($data['deadline']),
            'created_at' => sanitize_text_field($data['createdAt']),
            'updated_at' => sanitize_text_field($data['updatedAt'])
        );
        
        $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %s", $recruitment['id']));
        
        if ($existing) {
            $result = $wpdb->update($table_name, $recruitment, array('id' => $recruitment['id']));
        } else {
            $result = $wpdb->insert($table_name, $recruitment);
        }
        
        if ($result === false) {
            return array('success' => false, 'message' => 'Lỗi: ' . $wpdb->last_error);
        }
        
        return array('success' => true, 'message' => 'Đồng bộ thành công');
    }
}

new LTA_Recruitment_Sync();
